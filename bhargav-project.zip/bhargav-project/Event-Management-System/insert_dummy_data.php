<?php
// Database connection settings
require 'PARTS/db_connection_settings.php';

try {
    // Connect to MySQL database using PDO
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);

    // Set PDO error mode to exception
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    echo "Connected to database successfully.<br>";

    // Insert dummy users (IDs 3-10)
    $dummyUsers = [
        ['john_doe', 'john@example.com', 'male', 'user'],
        ['jane_smith', 'jane@example.com', 'female', 'user'],
        ['mike_johnson', 'mike@example.com', 'male', 'user'],
        ['sarah_wilson', 'sarah@example.com', 'female', 'user'],
        ['david_brown', 'david@example.com', 'male', 'user'],
        ['lisa_davis', 'lisa@example.com', 'female', 'user'],
        ['chris_miller', 'chris@example.com', 'male', 'user'],
        ['amy_taylor', 'amy@example.com', 'female', 'user']
    ];

    foreach ($dummyUsers as $index => $user) {
        $userId = $index + 3; // Start from ID 3
        $hashedPassword = password_hash('password' . $userId, PASSWORD_DEFAULT);
        $profilePic = $user[2] == 'male' ? '../ASSETS/IMG/DPFP/male.png' : '../ASSETS/IMG/DPFP/female.png';

        $insertUser = "INSERT INTO users (id, username, password, email, gender, role, profile_picture, can_request_event, can_review_request, can_delete_user, is_active)
                      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $pdo->prepare($insertUser);
        $stmt->execute([$userId, $user[0], $hashedPassword, $user[1], $user[2], $user[3], $profilePic, true, false, false, true]);
    }
    echo "Inserted " . count($dummyUsers) . " dummy users.<br>";

    // Insert dummy events
    $dummyEvents = [
        [3, 'Annual Tech Conference', 'A comprehensive technology conference covering latest trends', 'Main Auditorium', 480, 'active', '2024-01-15 09:00:00', '2024-01-15 17:00:00'],
        [4, 'Photography Workshop', 'Learn professional photography techniques', 'Studio A', 240, 'active', '2024-01-20 10:00:00', '2024-01-20 14:00:00'],
        [5, 'Music Festival', 'Outdoor music festival with local artists', 'Central Park', 360, 'ongoing', '2024-01-25 18:00:00', '2024-01-26 00:00:00'],
        [6, 'Business Networking', 'Networking event for entrepreneurs', 'Conference Room B', 180, 'pending', '2024-02-01 14:00:00', '2024-02-01 17:00:00'],
        [7, 'Art Exhibition', 'Showcase of contemporary art pieces', 'Gallery Hall', 300, 'active', '2024-02-05 11:00:00', '2024-02-05 16:00:00'],
        [8, 'Cooking Class', 'Learn to cook international cuisines', 'Kitchen Studio', 150, 'active', '2024-02-10 15:00:00', '2024-02-10 17:30:00'],
        [3, 'Science Fair', 'Annual science fair for students', 'Science Building', 420, 'completed', '2024-01-10 09:00:00', '2024-01-10 16:00:00'],
        [4, 'Book Reading', 'Author book reading and signing session', 'Library Hall', 120, 'active', '2024-02-15 19:00:00', '2024-02-15 21:00:00']
    ];

    foreach ($dummyEvents as $event) {
        $insertEvent = "INSERT INTO events (user_id, title, description, facility, duration, status, event_start, event_end)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $pdo->prepare($insertEvent);
        $stmt->execute($event);
    }
    echo "Inserted " . count($dummyEvents) . " dummy events.<br>";

    // Insert dummy comments
    $dummyComments = [
        [1, 3, 'Great event! Very informative and well organized.'],
        [2, 3, 'The speakers were excellent and the topics were very relevant.'],
        [4, 5, 'Amazing music! The atmosphere was fantastic.'],
        [5, 5, 'Best festival I\'ve attended this year!'],
        [6, 7, 'Beautiful artwork on display. Very inspiring.'],
        [7, 7, 'The artists did an amazing job with their pieces.'],
        [8, 8, 'Learned so many new cooking techniques!'],
        [3, 8, 'The chef was very knowledgeable and patient.'],
        [4, 1, 'This conference exceeded my expectations!'],
        [5, 2, 'Perfect workshop for beginners and professionals alike.']
    ];

    foreach ($dummyComments as $comment) {
        $insertComment = "INSERT INTO comments (event_id, user_id, comment) VALUES (?, ?, ?)";
        $stmt = $pdo->prepare($insertComment);
        $stmt->execute($comment);
    }
    echo "Inserted " . count($dummyComments) . " dummy comments.<br>";

    // Insert dummy event votes (likes/dislikes)
    $eventVotes = [
        [3, 1, 'like'], [4, 1, 'like'], [5, 1, 'like'], [7, 1, 'like'],
        [3, 2, 'like'], [5, 2, 'like'], [6, 2, 'like'], [8, 2, 'like'],
        [4, 3, 'like'], [5, 3, 'like'], [7, 3, 'like'],
        [5, 4, 'like'], [6, 4, 'like'], [8, 4, 'like'],
        [7, 5, 'like'], [8, 5, 'like'],
        [3, 6, 'dislike'], [4, 7, 'dislike'], [6, 8, 'dislike']
    ];

    foreach ($eventVotes as $vote) {
        $insertVote = "INSERT INTO event_votes (user_id, event_id, vote_type) VALUES (?, ?, ?)";
        $stmt = $pdo->prepare($insertVote);
        $stmt->execute($vote);
    }
    echo "Inserted " . count($eventVotes) . " dummy event votes.<br>";

    // Insert dummy comment votes
    $commentVotes = [
        [3, 1, 1, 'like'], [4, 1, 2, 'like'], [5, 1, 3, 'like'],
        [3, 2, 4, 'like'], [4, 2, 5, 'like'], [6, 2, 6, 'like'],
        [5, 3, 7, 'like'], [7, 3, 8, 'like'], [8, 3, 9, 'like'],
        [3, 4, 10, 'dislike'], [4, 4, 1, 'dislike']
    ];

    foreach ($commentVotes as $vote) {
        $insertVote = "INSERT INTO comment_votes (user_id, event_id, comment_id, vote_type) VALUES (?, ?, ?, ?)";
        $stmt = $pdo->prepare($insertVote);
        $stmt->execute($vote);
    }
    echo "Inserted " . count($commentVotes) . " dummy comment votes.<br>";

    // Update likes/dislikes counts based on votes
    // Update event likes/dislikes
    $updateEventStats = "UPDATE events e SET
                        likes = (SELECT COUNT(*) FROM event_votes WHERE event_id = e.id AND vote_type = 'like'),
                        dislikes = (SELECT COUNT(*) FROM event_votes WHERE event_id = e.id AND vote_type = 'dislike')";
    $pdo->exec($updateEventStats);
    echo "Updated event likes/dislikes counts.<br>";

    // Update comment likes/dislikes
    $updateCommentStats = "UPDATE comments c SET
                          likes = (SELECT COUNT(*) FROM comment_votes WHERE comment_id = c.id AND vote_type = 'like'),
                          dislikes = (SELECT COUNT(*) FROM comment_votes WHERE comment_id = c.id AND vote_type = 'dislike')";
    $pdo->exec($updateCommentStats);
    echo "Updated comment likes/dislikes counts.<br>";

    echo "<br><strong>Dummy data insertion completed successfully!</strong><br>";
    echo '<a href="index.php"><button>Go to Main Application</button></a>';

} catch(PDOException $e) {
    die("Error: " . $e->getMessage());
}
?>
