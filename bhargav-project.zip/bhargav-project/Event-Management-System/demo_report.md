# Event Management System (EMS) Demo Report

## Introduction

The Event Management System (EMS) is an open-source platform designed to streamline event organization and facility management. This demo report showcases the system's features using sample data and screenshots.

## Features Overview

- **Event Data Management:** Store and manage event details such as date, time, location, and facilities.
- **Online Event Scheduling:** Schedule events through an intuitive web interface.
- **Interactive Calendar:** View scheduled events and check facility availability.
- **User Profiles:** Create and customize user profiles.
- **Event Request and Approval Workflow:** Submit event requests for admin approval.
- **Comment and Feedback System:** Engage with events through comments, likes, and dislikes.
- **User Management:** Admins can manage user roles and permissions.
- **Security Features:** Secure login, password reset, and data protection.
- **Event Status Tracking:** Monitor events through various statuses.
- **Responsive Design:** Accessible on various devices.

## Demo Screenshots

Here are some screenshots of the EMS in action:

### Homepage
![Demo1](assets/demo_img/Demo1.png)

### Event Details
![Demo2](assets/demo_img/Demo2.png)

### Calendar View
![Demo3](assets/demo_img/Demo3n.png)

### User Dashboard
![Demo4](assets/demo_img/Demo4.png)

### Admin Panel
![Demo5](assets/demo_img/Demo5.png)

### Event Creation
![Demo6](assets/demo_img/Demo6.png)

### User Management
![Demo7](assets/demo_img/Demo7.png)

### Reports
![Demo8](assets/demo_img/Demo8.png)

### Settings
![Demo9](assets/demo_img/Demo9.png)

### Mobile View
![Demo10](assets/demo_img/Demo10.png)

## Demo Data

The system includes sample data for demonstration purposes:

- **Users:** Admin and regular users with profiles.
- **Events:** Various events in different statuses (ongoing, approved, pending, archived).
- **Facilities:** Sample locations for events.
- **Comments and Feedback:** Sample interactions on events.

To load demo data, run the `insert_dummy_data.php` script.

## Installation and Setup

1. Clone the repository.
2. Set up a web server (Apache/Nginx) and database (MySQL/PostgreSQL).
3. Configure database credentials in `PARTS/db_connection_settings.php`.
4. Run `database_setup.php` to initialize the database.
5. Access the application at `http://your-server/Event-Management-System`.

## Usage Guide

1. **Login:** Use default credentials (admin/admin_password or user/user_password).
2. **Create Events:** Navigate to request event and fill in details.
3. **Approve Events:** Admins can approve/deny requests.
4. **View Events:** Browse ongoing, approved, pending, and archived events.
5. **Interact:** Like, dislike, and comment on events.

## Technologies Used

- **Backend:** PHP 7.4+
- **Database:** MySQL/PostgreSQL
- **Frontend:** HTML, CSS (Bootstrap), JavaScript
- **Libraries:** FontAwesome, Bootstrap Icons

## Conclusion

EMS provides a comprehensive solution for event management. This demo report highlights its capabilities. For more information, visit the [GitHub repository](https://github.com/VoxDroid/Event-Management-System).

---

*This demo report can be edited to customize content, add more screenshots, or modify descriptions as needed.*
