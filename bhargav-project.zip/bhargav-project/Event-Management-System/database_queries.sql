-- Event Management System Database Setup Queries
-- This file contains all SQL queries for creating tables and inserting records

-- Create database if it doesn't exist
CREATE DATABASE IF NOT EXISTS event_management_system;

-- Use the database
USE event_management_system;

-- Create users table
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    reset_token VARCHAR(255),
    token_creation_time DATETIME,
    username VARCHAR(50) NOT NULL,
    password VARCHAR(255) NOT NULL,
    gender ENUM('male', 'female') NOT NULL,
    email VARCHAR(100),
    profile_picture VARCHAR(255),
    role ENUM('user', 'admin') NOT NULL,
    can_request_event BOOLEAN DEFAULT TRUE,
    can_review_request BOOLEAN DEFAULT FALSE,
    can_delete_user BOOLEAN DEFAULT FALSE,
    date_created TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    is_active BOOLEAN DEFAULT TRUE
);

-- Create events table
CREATE TABLE IF NOT EXISTS events (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    title VARCHAR(100) NOT NULL,
    description TEXT,
    facility VARCHAR(100) NOT NULL,
    duration INT NOT NULL,
    status ENUM('pending', 'active', 'denied', 'ongoing', 'completed') NOT NULL,
    date_requested TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    event_start DATETIME,
    event_end DATETIME,
    likes INT DEFAULT 0,
    dislikes INT DEFAULT 0,
    remarks VARCHAR(255),
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Create comments table
CREATE TABLE IF NOT EXISTS comments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    event_id INT NOT NULL,
    user_id INT NOT NULL,
    comment TEXT,
    likes INT DEFAULT 0,
    dislikes INT DEFAULT 0,
    date_commented TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (event_id) REFERENCES events(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Create comment_votes table
CREATE TABLE IF NOT EXISTS comment_votes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    event_id INT NOT NULL,
    comment_id INT NOT NULL,
    vote_type ENUM('like', 'dislike') NOT NULL,
    UNIQUE KEY user_comment_unique (user_id, event_id, comment_id),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (event_id) REFERENCES events(id) ON DELETE CASCADE,
    FOREIGN KEY (comment_id) REFERENCES comments(id) ON DELETE CASCADE
);

-- Create event_votes table
CREATE TABLE IF NOT EXISTS event_votes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    event_id INT NOT NULL,
    vote_type ENUM('like', 'dislike') NOT NULL,
    UNIQUE KEY user_event_unique (user_id, event_id),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (event_id) REFERENCES events(id) ON DELETE CASCADE
);

-- Insert default admin user (ID 1)
INSERT INTO users (id, username, password, role, can_request_event, can_review_request, can_delete_user, gender, profile_picture)
VALUES (1, 'admin', '$2y$10$hashed_password_here', 'admin', TRUE, TRUE, TRUE, 'male', '../ASSETS/IMG/DPFP/male.png');

-- Insert default user (ID 2)
INSERT INTO users (id, username, password, role, gender, profile_picture)
VALUES (2, 'user', '$2y$10$hashed_password_here', 'user', 'female', '../ASSETS/IMG/DPFP/female.png');

-- Insert dummy users (IDs 3-10)
INSERT INTO users (id, username, password, email, gender, role, profile_picture, can_request_event, can_review_request, can_delete_user, is_active)
VALUES
(3, 'john_doe', '$2y$10$hashed_password_here', 'john@example.com', 'male', 'user', '../ASSETS/IMG/DPFP/male.png', TRUE, FALSE, FALSE, TRUE),
(4, 'jane_smith', '$2y$10$hashed_password_here', 'jane@example.com', 'female', 'user', '../ASSETS/IMG/DPFP/female.png', TRUE, FALSE, FALSE, TRUE),
(5, 'mike_johnson', '$2y$10$hashed_password_here', 'mike@example.com', 'male', 'user', '../ASSETS/IMG/DPFP/male.png', TRUE, FALSE, FALSE, TRUE),
(6, 'sarah_wilson', '$2y$10$hashed_password_here', 'sarah@example.com', 'female', 'user', '../ASSETS/IMG/DPFP/female.png', TRUE, FALSE, FALSE, TRUE),
(7, 'david_brown', '$2y$10$hashed_password_here', 'david@example.com', 'male', 'user', '../ASSETS/IMG/DPFP/male.png', TRUE, FALSE, FALSE, TRUE),
(8, 'lisa_davis', '$2y$10$hashed_password_here', 'lisa@example.com', 'female', 'user', '../ASSETS/IMG/DPFP/female.png', TRUE, FALSE, FALSE, TRUE),
(9, 'chris_miller', '$2y$10$hashed_password_here', 'chris@example.com', 'male', 'user', '../ASSETS/IMG/DPFP/male.png', TRUE, FALSE, FALSE, TRUE),
(10, 'amy_taylor', '$2y$10$hashed_password_here', 'amy@example.com', 'female', 'user', '../ASSETS/IMG/DPFP/female.png', TRUE, FALSE, FALSE, TRUE);

-- Insert dummy events
INSERT INTO events (user_id, title, description, facility, duration, status, event_start, event_end) VALUES
(3, 'Annual Tech Conference', 'A comprehensive technology conference covering latest trends', 'Main Auditorium', 480, 'active', '2024-01-15 09:00:00', '2024-01-15 17:00:00'),
(4, 'Photography Workshop', 'Learn professional photography techniques', 'Studio A', 240, 'active', '2024-01-20 10:00:00', '2024-01-20 14:00:00'),
(5, 'Music Festival', 'Outdoor music festival with local artists', 'Central Park', 360, 'ongoing', '2024-01-25 18:00:00', '2024-01-26 00:00:00'),
(6, 'Business Networking', 'Networking event for entrepreneurs', 'Conference Room B', 180, 'pending', '2024-02-01 14:00:00', '2024-02-01 17:00:00'),
(7, 'Art Exhibition', 'Showcase of contemporary art pieces', 'Gallery Hall', 300, 'active', '2024-02-05 11:00:00', '2024-02-05 16:00:00'),
(8, 'Cooking Class', 'Learn to cook international cuisines', 'Kitchen Studio', 150, 'active', '2024-02-10 15:00:00', '2024-02-10 17:30:00'),
(3, 'Science Fair', 'Annual science fair for students', 'Science Building', 420, 'completed', '2024-01-10 09:00:00', '2024-01-10 16:00:00'),
(4, 'Book Reading', 'Author book reading and signing session', 'Library Hall', 120, 'active', '2024-02-15 19:00:00', '2024-02-15 21:00:00');

-- Insert dummy comments
INSERT INTO comments (event_id, user_id, comment) VALUES
(1, 3, 'Great event! Very informative and well organized.'),
(2, 3, 'The speakers were excellent and the topics were very relevant.'),
(4, 5, 'Amazing music! The atmosphere was fantastic.'),
(5, 5, 'Best festival I\'ve attended this year!'),
(6, 7, 'Beautiful artwork on display. Very inspiring.'),
(7, 7, 'The artists did an amazing job with their pieces.'),
(8, 8, 'Learned so many new cooking techniques!'),
(3, 8, 'The chef was very knowledgeable and patient.'),
(4, 1, 'This conference exceeded my expectations!'),
(5, 2, 'Perfect workshop for beginners and professionals alike.');

-- Insert dummy event votes
INSERT INTO event_votes (user_id, event_id, vote_type) VALUES
(3, 1, 'like'), (4, 1, 'like'), (5, 1, 'like'), (7, 1, 'like'),
(3, 2, 'like'), (5, 2, 'like'), (6, 2, 'like'), (8, 2, 'like'),
(4, 3, 'like'), (5, 3, 'like'), (7, 3, 'like'),
(5, 4, 'like'), (6, 4, 'like'), (8, 4, 'like'),
(7, 5, 'like'), (8, 5, 'like'),
(3, 6, 'dislike'), (4, 7, 'dislike'), (6, 8, 'dislike');

-- Insert dummy comment votes
INSERT INTO comment_votes (user_id, event_id, comment_id, vote_type) VALUES
(3, 1, 1, 'like'), (4, 1, 2, 'like'), (5, 1, 3, 'like'),
(3, 2, 4, 'like'), (4, 2, 5, 'like'), (6, 2, 6, 'like'),
(5, 3, 7, 'like'), (7, 3, 8, 'like'), (8, 3, 9, 'like'),
(3, 4, 10, 'dislike'), (4, 4, 1, 'dislike');

-- Update likes/dislikes counts for events
UPDATE events e SET
    likes = (SELECT COUNT(*) FROM event_votes WHERE event_id = e.id AND vote_type = 'like'),
    dislikes = (SELECT COUNT(*) FROM event_votes WHERE event_id = e.id AND vote_type = 'dislike');

-- Update likes/dislikes counts for comments
UPDATE comments c SET
    likes = (SELECT COUNT(*) FROM comment_votes WHERE comment_id = c.id AND vote_type = 'like'),
    dislikes = (SELECT COUNT(*) FROM comment_votes WHERE comment_id = c.id AND vote_type = 'dislike');
